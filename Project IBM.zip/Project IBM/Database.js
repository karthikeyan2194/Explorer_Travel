
var request = indexedDB.open('UserResponsesDB', 1);
var db;

request.onerror = function(event) {
    console.log('Error opening database:', event.target.errorCode);
};

request.onupgradeneeded = function(event) {
    
    db = event.target.result;
    var objectStore = db.createObjectStore('responses', { keyPath: 'id', autoIncrement: true });

   
    objectStore.createIndex('name', 'name', { unique: false });
    objectStore.createIndex('phone', 'phone', { unique: false });
    objectStore.createIndex('message', 'message', { unique: false });
};

request.onsuccess = function(event) {
    db = event.target.result;
    displayUserResponses();
};


function saveUserInput(name, phone, message) {
   
    var transaction = db.transaction(['responses'], 'readwrite');
    var objectStore = transaction.objectStore('responses');

   
    var request = objectStore.add({ name: name, phone: phone, message: message });

    request.onsuccess = function(event) {
        console.log('Response added to the database.');
        displayUserResponses();
    };

    request.onerror = function(event) {
        console.log('Error adding response to the database:', event.target.error);
    };
}

function displayUserResponses() {
   
    var transaction = db.transaction(['responses'], 'readonly');
    var objectStore = transaction.objectStore('responses');
    var tableBody = document.getElementById('responseTableBody');
    tableBody.innerHTML = '';

    objectStore.openCursor().onsuccess = function(event) {
        var cursor = event.target.result;

        if (cursor) {
            var row = tableBody.insertRow();
            var nameCell = row.insertCell(0);
            var phoneCell = row.insertCell(1);
            var messageCell = row.insertCell(2);

            nameCell.textContent = cursor.value.name;
            phoneCell.textContent = cursor.value.phone;
            messageCell.textContent = cursor.value.message;

            cursor.continue();
        }

       
        var responseTable = document.getElementById('responseTable');
        if (tableBody.innerHTML !== '') {
            responseTable.style.display = 'table';
        }
    };
}
