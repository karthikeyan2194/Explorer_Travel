document.addEventListener('DOMContentLoaded', function () {
    const buttonsContainer = document.querySelector('.buttons-container');

    
    const buttonsCreated = buttonsContainer.getAttribute('data-buttons-created');

    if (!buttonsCreated) {
        const buttonData = [
            { link: '#', image: 'Cities_Logos/mumbai_logo.jpg',text: 'Mumbai'},
            { link: '#', image: 'Cities_Logos/ahmedabad _logo2.jpg', text: 'Ahmedabad' },
            { link: '#', image: 'Cities_Logos/bangalore_logo2.jpg', text: 'Bangalore' },
            { link: '#', image: 'Cities_Logos/hyderabad_logo2.jpg', text: 'Hyderabad' },
            { link: '#', image: 'Cities_Logos/delhi _logo2.jpg', text: 'New Delhi' }
        ];

       
        buttonData.forEach(item => {
            const button = document.createElement('button');
            button.classList.add('btn');

           
            const image = document.createElement('img');
            image.src = item.image;
            image.alt = item.text;
            image.style.marginRight = '0px'; 
            
            button.appendChild(image);

            
            const buttonText = document.createElement('span');
            buttonText.textContent = item.text;

            
            button.appendChild(buttonText);

           
            button.setAttribute('onclick', `showTransportList('${item.text}')`);

            
            buttonsContainer.appendChild(button);
        });

        
        buttonsContainer.setAttribute('data-buttons-created', 'true');
    }
});

function showTransportList(city) {
    
    const selectedMode = sessionStorage.getItem('selectedMode');

   
    const buttonsContainer = document.querySelector('.buttons-container');
    buttonsContainer.innerHTML = '';

    
    const heading = document.createElement('h2');
    heading.textContent = `${selectedMode} to ${city}`;

    
    buttonsContainer.appendChild(heading);

   
    const transportListContainer = document.createElement('div');
    transportListContainer.classList.add('transport-list-container');

    
    const transportList = getTransportList(selectedMode, city);

    
    transportList.forEach(item => {
        const itemElement = document.createElement('p');
        if (selectedMode === 'Airways') {
            itemElement.textContent = `${item.airline} ${item.flightNumber} - Departure: ${item.departureTime} Arrival: ${item.arrivalTime}`;
        } else if (selectedMode === 'Railways') {
            itemElement.textContent = `${item.trainNumber} ${item.trainName} (${item.runningDays}) - Departure: ${item.departureTime} Duration: ${item.duration} Arrival: ${item.arrivalTime}`;
        }
        transportListContainer.appendChild(itemElement);
    });

    
    buttonsContainer.appendChild(transportListContainer);

   
    const nextButton = document.createElement('button');
    nextButton.textContent = 'Next';
    nextButton.classList.add('bttn', 'next-button');
    nextButton.addEventListener('click', function () {
        let nextUrl;
        switch (city) {
            case 'Mumbai':
                nextUrl = 'mumbai.html';
                break;
            case 'Ahmedabad':
                nextUrl = 'Ahmedabad.html';
                break;
            case 'Bangalore':
                nextUrl = 'Bangalore.html';
                break;
            case 'Hyderabad':
                nextUrl = 'Hyderabad.html';
                break;
            case 'New Delhi':
                nextUrl = 'NewDelhi.html';
                break;
            default:
                nextUrl = 'Index.html';
        }

       
        window.location.href = nextUrl;
    });

    
    buttonsContainer.appendChild(nextButton);
}


function getTransportList(mode, city) {
    
    if (mode === 'Airways') {
        
        if (city === 'Mumbai') {
            return [
                { airline: 'Akasa air', flightNumber: 'QP 1305', departureTime: '21:40', arrivalTime: '23:50' },
                { airline: 'Spicejet', flightNumber: 'SG 612', departureTime: '21:30', arrivalTime: '23:40' },
                { airline: 'Spicejet', flightNumber: 'SG 678', departureTime: '05:10', arrivalTime: '06:45' },
                { airline: 'Air India', flightNumber: 'AI 574', departureTime: '21:15', arrivalTime: '23:20' },
                { airline: 'Indigo', flightNumber: '6E 6347', departureTime: '02:40', arrivalTime: '04:35' }
            ];
        } else if (city === 'Ahmedabad') {
            return [
                {airline: 'SpiceJet', flightNumber: 'SG 616', departureTime: '21:00', arrivalTime: '23:15' },
                { airline: 'IndiGo', flightNumber: '6E 848', departureTime: '17:55', arrivalTime: '20:10' },
                { airline: 'Air India', flightNumber: 'AI 538, 531', departureTime: '20:30', arrivalTime: '21:20' },
                { airline: 'Vistara', flightNumber: 'UK 824, 939', departureTime: '20:30', arrivalTime: '21:10' }
            ];
        } else if(city==='Bangalore'){
            return[
                { airline: 'IndiGo', flightNumber: '6E 796', departureTime: '23:15', arrivalTime: '00:15' },
                { airline: 'Air India Express', flightNumber: 'IX 821', departureTime: '22:05', arrivalTime: '23:10' },
                { airline: 'Air India', flightNumber: 'AI 538, 807', departureTime: '20:30', arrivalTime: '22:10' },
                { airline: 'Air India', flightNumber: 'AI 539', departureTime: '17:00', arrivalTime: '19:45' }
            ];
        }else if(city==='Hyderabad'){
            return[
                { airline: 'IndiGo', flightNumber: '6E 562', departureTime: '17:30', arrivalTime: '18:40' },
                { airline: 'Alliance Air', flightNumber: '9I 872', departureTime: '22:20', arrivalTime: '23:55' },
                { airline: 'Vistara', flightNumber: 'UK 824, 531', departureTime: '20:30', arrivalTime: '21:50' },
                { airline: 'Air India', flightNumber: 'AI 575, 615', departureTime: '20:20', arrivalTime: '22:00' },
                { airline: 'Air India', flightNumber: '6E 6158', departureTime: '16:30', arrivalTime: '17:40' }
            ];
        } else if (city==='New Delhi'){
            return[
                { airline: 'IndiGo', flightNumber: '6E 2166', departureTime: '21:15', arrivalTime: '00:05' },
                { airline: 'SpiceJet', flightNumber: 'SG 8106', departureTime: '18:25', arrivalTime: '21:15' },
                { airline: 'Vistara', flightNumber: 'UK 824, 928', departureTime: '20:30', arrivalTime: '22:00' },
                { airline: 'Air India Express', departureTime: '18:10', arrivalTime: '22:30' },
                { airline: 'Air India', flightNumber: 'AI 575, 442', departureTime: '20:20', arrivalTime: '23:00' }
            ];
        }
    } else if (mode === 'Railways') {
        if (city ==='Mumbai'){
            return[
                { trainNumber: '22158', trainName: 'MS CSMT SF EXP', runningDays: 'All days', departureStation: 'MS', departureTime: '06:20', duration: '23h 30m', arrivalStation: 'CSMT', arrivalTime: '05:50' },
                { trainNumber: '22160', trainName: 'MAS CSMT SF EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '13:15', duration: '23h 15m', arrivalStation: 'CSMT', arrivalTime: '12:30' }
            ];
        } else if (city==='Ahmedabad') {
            return [
                { trainNumber: '12656', trainName: 'NAVAJIVAN SF EXP', runningDays: 'ALL DAYS', departureStation: 'MAS', departureTime: '10:10', duration: '1d 7h 50m', arrivalStation: 'ADI', arrivalTime: '18:00' },
                { trainNumber: '22663', trainName: 'MS JODHPUR EXP', runningDays: 'SATURDAY', departureStation: 'MS', departureTime: '15:30', duration: '1d 8h 10m', arrivalStation: 'ADI', arrivalTime: '23:40' },
                { trainNumber: '22919', trainName: 'ADI HUMSAFAR', runningDays: 'WEDNESDAY', departureStation: 'MAS', departureTime: '16:00', duration: '1d 5h 15m', arrivalStation: 'ADI', arrivalTime: '21:15' }
            ];
        } else if(city==='Bangalore'){
            return[
                { trainNumber: '20607', trainName: 'MYS VANDEBHARAT', runningDays: 'S M T T F S', departureStation: 'MAS', departureTime: '05:50', duration: '4h 20m', arrivalStation: 'SBC', arrivalTime: '10:10' },
                { trainNumber: '22625', trainName: 'SBC DBLDECK EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '07:25', duration: '5h 45m', arrivalStation: 'SBC', arrivalTime: '13:10' },
                { trainNumber: '12609', trainName: 'MYSURU EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '13:35', duration: '6h 20m', arrivalStation: 'SBC', arrivalTime: '19:55' },
                { trainNumber: '16021', trainName: 'KAVERI EXPRESS', runningDays: 'All days', departureStation: 'MAS', departureTime: '21:15', duration: '6h 30m', arrivalStation: 'SBC', arrivalTime: '03:45' },
                { trainNumber: '12607', trainName: 'LALBAGH SF EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '15:30', duration: '6h 5m', arrivalStation: 'SBC', arrivalTime: '21:35' },
                { trainNumber: '12027', trainName: 'MAS SBC SHATABDI', runningDays: 'S M W T F S', departureStation: 'MAS', departureTime: '17:25', duration: '5h', arrivalStation: 'SBC', arrivalTime: '22:25' },
                { trainNumber: '12007', trainName: 'MYS SHATABDI', runningDays: 'S M T T F S', departureStation: 'MAS', departureTime: '06:00', duration: '4h 40m', arrivalStation: 'SBC', arrivalTime: '10:40' },
                { trainNumber: '12639', trainName: 'BRINDAVAN SF EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '07:40', duration: '6h', arrivalStation: 'SBC', arrivalTime: '13:40' }
            ];
        }else if(city==='Hyderabad'){
            return[
                { trainNumber: '12603', trainName: 'MAS HYB SF EXP', runningDays: 'All days', departureStation: 'MAS', departureTime: '16:45', duration: '13h 5m', arrivalStation: 'HYB', arrivalTime: '05:50' },
                { trainNumber: '12759', trainName: 'CHARMINAR EXP', runningDays: 'All days', departureStation: 'MS', departureTime: '18:00', duration: '14h', arrivalStation: 'HYB', arrivalTime: '08:10' }
            ];
        } else if (city==='New Delhi'){
            return [
                { trainNumber: '12621', trainName: 'TamilNadu Exp', runningDays: 'All days', departureStation: 'MAS', departureTime: '22:00', duration: '1d 8h 30m', arrivalStation: 'NDLS', arrivalTime: '06:30' },
                { trainNumber: '12615', trainName: 'Grand Trunk Exp', runningDays: 'All days', departureStation: 'MAS', departureTime: '18:40', duration: '1d 10h 25m', arrivalStation: 'NDLS', arrivalTime: '05:05' },
                { trainNumber: '12433', trainName: 'Mas Nzm Rajdhani', runningDays: 'Sunday & Friday', departureStation: 'MAS', departureTime: '06:05', duration: '1d 4h 25m', arrivalStation: 'NZM', arrivalTime: '10:30' },
                { trainNumber: '16031', trainName: 'Andaman Express', runningDays: 'Sun Wed Fri only', departureStation: 'MAS', departureTime: '05:15', duration: '1d 15h 40m', arrivalStation: 'NDLS', arrivalTime: '20:55' }

         ];
        }

    return [];
}

}

