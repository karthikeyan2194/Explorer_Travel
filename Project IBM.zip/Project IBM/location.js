function showTransportRoute(destination) {
    console.log ('Function executed!', destination);
    const selectedMode = sessionStorage.getItem('selectedMode');
    const buttonsContainer = document.querySelector('.buttons-container');
    buttonsContainer.innerHTML = '';


    const transportRouteContainer = document.createElement('div');
    transportRouteContainer.classList.add('transport-route-container');
    const transportRoute= getTransportRoute(selectedMode, destination);

    document.getElementById('airways-route').innerHTML = '';
    document.getElementById('railways-route').innerHTML = '';

        if (selectedMode === 'Airways') {
        const airwaysRouteContainer = document.getElementById('airways-route');
        transportRoute.airways.forEach(route => {
            const routeElement = document.createElement('p');
            routeElement.textContent = route;
            airwaysRouteContainer.appendChild(routeElement);
        });
    } else if (selectedMode === 'Railways') {
        const railwaysRouteContainer = document.getElementById('railways-route');
        transportRoute.railways.forEach(route => {
            const routeElement = document.createElement('p');
            routeElement.textContent = route;
            railwaysRouteContainer.appendChild(routeElement);
        });
    }
}

function getTransportRoute(mode, destination){
    console.log('getTransportRoute executed!', mode, destination);
    if (mode === 'Airways') {
        if(destination === 'Bandra Worli Sea Link'){
        return {
            airways: [
                'Mumbai Airport',
                'Direct route through last mile connectivity',
                'Bandra'
               
            ],
            railways: [] 
        }
        } else if (destination === 'Elephanta Caves'){
            return {
                airways: [
                    'Mumbai Airport',
                    'Direct route through last mile connectivity',
                    'Elephanta Caves'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Gateway of India'){
            return {
                airways: [
                    'Mumbai Airport',
                    'Mumbai domestic Airport METRO',
                    'Mumbai Central',
                    'Churchgate',
                    'Direct route through last mile connectivity',
                    'Gateway of India'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Juhu Beach'){
            return {
                airways: [
                    'Mumbai Airport',
                    'Mumbai domestic Airport METRO',
                    'Mumbai Central',
                    'Villa Parle Station',
                    'Juhu Beach'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Marine Drive'){
            return {
                airways: [
                    'Mumbai Airport',
                    'Mumbai domestic Airport METRO',
                    'Mumbai Central',
                    'Direct route through last mile connectivity',
                    'Mahim Junction',
                    'Marine Drive'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Aquatic Gallery'){
            return {
                airways: [
                    'Ahmedabad Airport',
                    'Sabarmati METRO Station',

                    'Ahmedabad Junction',
                    'Chandlodiya Outer Cabin Junction',
                    'Aquatic Gallery'
                   
                ],
                railways: [] 
            }
        } else if (destination === 'Nehru Zoo'){
            return {
                airways: [
                    'Ahmedabad Airport',
                    'Sabarmati METRO Station',

                    'Ahmedabad Junction',
                    'Kankaria',
                    'KAMALA NEHRU ZOO',
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Sabarmati Ashram'){
            return {
                airways: [
                    'Ahmedabad Airport',
                    'Sabarmati METRO Station',


                    'Ahmedabad Junction',
                    'Gandhigram',
                    'SABARMATI RIVER FORT'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Statue of Unity'){
            return {
                airways: [
                    'Ahmedabad Airport',
                    'Sabarmati METRO Station',

                    'Ahmedabad Junction',
                    'Ekta Nagar [Kevadiya]',
                    'STATUE OF UNITY'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Vidhana Soudha'){
            return {
                airways: [
                    'Bangalore Airport',

                    'Last mile connectivty to METRO',

                    'Majestic Metro',
                    'VIDHAN SOUDHA [METRO]'
                   
                ],
                railways: [] 
            }
        } else if (destination === 'LalBagh Gardens'){
            return {
                airways: [
                    'Bangalore Airport',

                    'Last mile connectivty to METRO',

                    'Majestic Metro',
                    'LALBAGH BOTANICAL GARDEN [METRO]'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'MG Road'){
            return {
                airways: [
                    'Bangalore Airport',

                    'Last mile connectivty to METRO',


                    'Majestic Metro',
                    'MG ROAD [METRO]',
                    'Mahatma Gandhi Road'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Wonderla'){
            return {
                airways: [
                    'Bangalore Airport',

                    'Last mile connectivty to METRO',


                    'Majestic Metro',
                   'Wonderla Amusement Metro'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Bannerghatta'){
            return {
                airways: [
                    'Bangalore Airport',

                    'Last mile connectivty to METRO',
                    'Majestic Metro',
                    'J.P.Nagar METRO Station,14 kms away from Bannerghatta',
                    'Last mile connectivity to Bannerghatta'
                   
                ],
                railways: [] 
            }
        } else if (destination === 'Charminar'){
            return {
                airways: [
                    'Rajiv Gandhi International Airort',
                    'Rajiv Gandhi International METRO station',
                    'Nampally Station (HYD CENTRAL)',
                    'Charminar'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'GolcondaFort'){
            return {
                airways: [
                    'Rajiv Gandhi International Airort',
                    'Rajiv Gandhi International METRO station',

                    'Nampally Station (HYD CENTRAL)',
                    'Golconda Bus Station',
                    'Golconda Fort'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'RamojiRao'){
            return {
                airways: [
                    'Rajiv Gandhi International Airort',
                    'Rajiv Gandhi International METRO station',

                    'Nampally Station (HYD CENTRAL)',
                    'Ramoji Film City Office',
                    'RAMOJI FILM CITY'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Jalawihar'){
            return {
                airways: [
                    'Rajiv Gandhi International Airort',
                    'Rajiv Gandhi International METRO station',

                    'Nampally Station (HYD CENTRAL)',
                    'Khairatabad',
                    'JALAVIHAR WATER PARK'
                   
                ],
                railways: [] 
            }
        } else if (destination === 'Bawarchirestaurant'){
            return {
                airways: [
                    'Rajiv Gandhi International Airort',
                    'Rajiv Gandhi International METRO station',


                    'Nampally',
                    'Chikkadapalli Metro Station',
                    'BAWARCHI RESTAURANT'
                ],
                railways: [] 
            }
        } else if (destination === 'Taj Mahal'){
            return {
                airways: [
                    'IGI Airport',
                    'IGI Airport METRO Station',

                    'HNZM Station',
                    'Agra Cantt Station',
                    'TAJ MAHAL'
                
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Qutub Minar'){
            return {
                airways: [
                    'IGI Airport',
                    'IGI Airport METRO Station',
                    'Hazrat Nizamuddin',
                    'Qutub Minar',
                    'QUTUB MINAR [METRO]'
                    
                ],
                railways: [] 
            }
        } else if (destination === 'Red Fort'){
            return {
                airways: [
                    'IGI Airport',
                    'IGI Airport METRO Station',
                    'Hazrat Nizamuddin',
                    'RED FORT [METRO]',
                    'Red Fort'
                ],
                railways: [] 
            }
        } else if (destination === 'Lotus Temple'){
            return {
                airways: [
                    'IGI Airport',
                    'IGI Airport METRO Station',
                    'Hazrat Nizamuddin',
                    'Kalkaji Mandir',
                    'LOTUS TEMPLE [METRO]'

                    
                ],
                railways: [] 
            }
        }else if (destination === 'India Gate '){
                return {
                    airways: [
                        'IGI Airport',
                     'IGI Airport METRO Station',
                        'Hazrat Nizamuddin',
                        'Mandi House',
                        'INDIA GATE [METRO]'
                    ],
                    railways: [] 
                }
        }
        } else if (mode === 'Railways') {
        if(destination === 'Bandra Worli Sea Link'){
       
        return {
            airways: [],
            railways: [
                'Mumbai Central',
                'Direct route through last mile connectivity',
                'Bandra'
               
            ]
        }
        } else if (destination === 'Elephanta Caves '){
            return {
                airways: [],
                railways: [
                    'Mumbai Central',
                    'Churchgate Railway station',
                    'Elephanta Caves'
                   
                ]
            }
        } else if (destination === 'Gateway of India'){
            return {
                airways: [],
                railways: [
    
                    'Mumbai Central',
                    'Churchgate',
                    'Direct route through last mile connectivity',
                    'Gateway of India'
                   
                ]
            }
        } else if (destination === 'Juhu Beach'){
            return {
                airways: [],
                railways: [
                    'Mumbai Central',
                    'Villa Parle Station',
                    'Juhu Beach'
                   
                ]
            }
        } else if (destination === 'Marine Drive'){
            return {
                airways: [],
                railways: [
                    'Mumbai Central',
        
                    'Mahim Junction',
                    'Marine Drive'
                   
                ]
            }
        } else if (destination === 'Aquatic Gallery'){
            return {
                airways: [],
                railways: [
                   

                    'Ahmedabad Junction',
                    'Chandlodiya Outer Cabin Junction',
                    'Aquatic Gallery',
                   
                   
                ]
            }
        } else if (destination === 'Nehru Zoo'){
            return {
                airways: [],
                railways: [
                    'Ahmedabad Junction',
                    'Kankaria',
                    'KAMALA NEHRU ZOO',
                   
                ]
            }
        } else if (destination === 'Sabarmati Ashram'){
            return {
                airways: [],
                railways: [
                    'Ahmedabad Junction',
                    'Gandhigram',
                    'SABARMATI RIVER FORT'
                ]
            }
        } else if (destination === 'Statue of Unity'){
            return {
                airways: [],
                railways: [
                    'Ahmedabad Junction',
                    'Ekta Nagar [Kevadiya]',
                    'STATUE OF UNITY'
                   
                ]
            }
        } else if (destination === 'Vidhana Soudha'){
            return {
                airways: [],
                railways: [
                    'Bangalore Central/Cantt Station',
                    'Last mile connectivty to METRO',

                    'Majestic Metro',
                    'Vidhana Soudha Metro'
                   
                ]
            }
        } else if (destination === 'LalBagh Gardens'){
            return {
                airways: [],
                railways: [
                    'Bangalore Central/Cantt Station',

                    'Last mile connectivty to METRO',

                    'Majestic Metro',
                    'LALBAGH BOTANICAL GARDEN [METRO]'
                   
                ]
            }
        } else if (destination === 'MG Road'){
            return {
                airways: [],
                railways: [
                    'Bangalore Central/Cantt Station',

                    'Majestic Metro',
                    'Mahatma Gandhi Road'
                   
                ]
            }
        } else if (destination === 'Wonderla'){
            return {
                airways: [],
                railways: [
                    'Bangalore Central/Cantt Station',

                    'Majestic Metro',
                   'Wonderla Amusement Metro'
                ]
            }
        } else if (destination === 'Bannerghatta'){
            return {
                airways: [],
                railways: [
                    'Bangalore Central/Cantt Station',
                    'Last mile connectivty to METRO',

                    'Majestic Metro',
                    'J.P.Nagar METRO Station,14 kms away from Bannerghatta',
                    'Last mile connectivity to Bannerghatta'
                   
                ]
            }
        } else if (destination === 'Charminar'){
            return {
                airways: [],
                railways: [
                    

                    'Nampally Station (HYD CENTRAL)',
                    'Charminar Station',
                    'CHARMINAR'
                   
                ]
            }
        } else if (destination === 'GolcondaFort'){
            return {
                airways: [],
                railways: [

                    'Nampally Station (HYD CENTRAL)',
                    'Golconda Bus Station',
                    'GOLCONDA FORT'
                   
                ]
            }
        } else if (destination === 'RamojiRao'){
            return {
                airways: [],
                railways: [
                   

                    'Nampally Station (HYD CENTRAL)',
                     'Ramoji Film City Office',
                     'RAMOJI FILM CITY',
                   
                ]
            }
        } else if (destination === 'Jalawihar'){
            return {
                airways: [],
                railways: [
                   

                    'Nampally Station (HYD CENTRAL)',
                    'Khairatabad',
                    'JALAVIHAR WATER PARK',

                   
                ]
            }
        } else if (destination === 'Bawarchirestaurant'){
            return {
                airways: [],
                railways: [

                    'Nampally Station (HYD CENTRAL)',
                    'Chikkadapalli Metro Station',
                    'BAWARCHI RESTAURANT'
                   
                ]
            }
        } else if (destination === 'Taj Mahal'){
            return {
                airways: [],
                railways: [

                    'HNZM Station',
                    'Agra Cantt Station',
                    'Agra',
                    'TAJ MAHAL'

                   
                ]
            }
        } else if (destination === 'Qutub Minar'){
            return {
                airways: [],
                railways: [
                    'QUTUB MINAR [METRO]',

                    'Hazrat Nizamuddin',
                    'QUTUB MINAR [METRO]',
                    'Qutub Minar'
                   
                ]
            }
        } else if (destination === 'India Gate'){
            return {
                airways: [],
                railways: [

                    'Hazrat Nizamuddin',
                    'Mandi House',
                    'INDIA GATE [METRO]',
                    'India Gate'

                   
                ]
            }
        } else if (destination === 'Red Fort'){
            return {
                airways: [],
                railways: [
                  
                    'Hazrat Nizamuddin',
                    'RED FORT [METRO]',
                    'Red Fort'
                   
                ]
            }
        } else if (destination === 'Lotus Temple'){
            return {
                airways: [],
                railways: [
                   
                    'Hazrat Nizamuddin',
                    'Kalkaji Mandir',
                    'LOTUS TEMPLE [METRO]',
                    'Lotus Temple'


                   
                ]
            }
        }
    }

    return { airways: [], railways: [] };
    }